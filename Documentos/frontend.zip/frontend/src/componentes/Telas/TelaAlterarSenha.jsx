import PaginaGeral from "../layouts/PaginaGeral";
import AlterarSenha from "../Telas/Formularios/AlterarSenha";

export default function TelaAlterarSenha(){
    return(
        <PaginaGeral>
            <AlterarSenha/>
        </PaginaGeral>
    );
}