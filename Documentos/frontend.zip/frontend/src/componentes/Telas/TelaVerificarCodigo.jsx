import VerificarCodigo from "./Formularios/VerificarCodigo";

export default function TelaRVerificarCodigo(){
    return(
        <VerificarCodigo/>
    );
}