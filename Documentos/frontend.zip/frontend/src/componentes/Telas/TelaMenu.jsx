import Pagina from "../layouts/PaginaInicial";

export default function TelaMenu(props){
    return (
        <Pagina />
    );
}