import VerificarEmail from "./Formularios/VerificarEmail";

export default function TelaVerificarEmail(){
    return(
        <VerificarEmail/>
    );
}