import Login from "./Formularios/Login";

export default function TelaLogin(props){
    return (
        < Login/> 
    );
}