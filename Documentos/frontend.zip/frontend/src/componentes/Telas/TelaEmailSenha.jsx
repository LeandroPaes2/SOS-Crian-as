import PaginaGeral from "../layouts/PaginaGeral";
import EmailSenha from "./Formularios/EmailSenha";

export default function TelaEmailSenha(){

    return(
        <PaginaGeral>
            <EmailSenha/>
        </PaginaGeral>
    );
}